<x-filament::page>
    @livewire('live-tracking-map')
</x-filament::page>
