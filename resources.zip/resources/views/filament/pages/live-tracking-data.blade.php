<x-filament::page>
    <div class="flex justify-between mb-4">
        <h2 class="text-xl font-bold">Real-Time Vehicle Tracking</h2>
        <x-filament::button wire:click="refreshData" color="primary">
            Refresh
        </x-filament::button>
    </div>

    <table class="min-w-full divide-y divide-gray-200">
        <thead>
            <tr class="bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                <th class="px-4 py-2">Vehicle ID</th>
                <th class="px-4 py-2">Latitude</th>
                <th class="px-4 py-2">Longitude</th>
                <th class="px-4 py-2">Last Update</th>
            </tr>
        </thead>
        <tbody class="bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
            @foreach ($vehicles as $vehicle)
                <tr>
                    <td class="px-4 py-2 font-semibold ">{{ $vehicle->name }}</td>
                    <td class="px-4 py-2">{{ $vehicle->latitude }}</td>
                    <td class="px-4 py-2">{{ $vehicle->longitude }}</td>
                    <td class="px-4 py-2">{{ $vehicle->updated_at->diffForHumans() }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>
</x-filament::page>