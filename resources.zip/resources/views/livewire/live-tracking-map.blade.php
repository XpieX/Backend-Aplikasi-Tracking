<div>
    <h2 class="text-lg font-semibold mb-4 text-black">Live Tracking Kendaraan</h2>

    <div class="rounded-lg border shadow p-4 bg-white max-w-full">
        <div id="map" class="w-full h-[500px] rounded"></div>
    </div>

    @push('styles')
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.css" />
    @endpush

    @push('scripts')
        <script src="https://cdn.jsdelivr.net/npm/leaflet@1.7.1/dist/leaflet.js"></script>
        <script src="https://js.pusher.com/7.2/pusher.min.js"></script>

        <script>
            document.addEventListener('livewire:load', () => {
                const map = L.map('map').setView([-0.056170, 109.310976], 10);
                L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                    maxZoom: 19,
                }).addTo(map);

                const vehicles = @json($vehicles);
                const markers = {};

                vehicles.forEach(vehicle => {
                    const marker = L.marker([vehicle.latitude, vehicle.longitude])
                        .addTo(map)
                        .bindPopup(`Vehicle: ${vehicle.name}`);
                    markers[vehicle.id] = marker;
                });

                const pusher = new Pusher('50678e8196ba007f9922', {
                    cluster: 'ap1',
                    forceTLS: true,
                });

                const channel = pusher.subscribe('vehicle-tracking');
                channel.bind('location.updated', data => {
                    const { vehicle_id, lat, lng } = data;
                    if (markers[vehicle_id]) {
                        markers[vehicle_id].setLatLng([lat, lng]);
                    } else {
                        const marker = L.marker([lat, lng])
                            .addTo(map)
                            .bindPopup(`Vehicle ID: ${vehicle_id}`);
                        markers[vehicle_id] = marker;
                    }
                    map.panTo([lat, lng]);
                });

                setTimeout(() => map.invalidateSize(), 100);
                window.addEventListener('resize', () => map.invalidateSize());
            });
        </script>
    @endpush
</div>
